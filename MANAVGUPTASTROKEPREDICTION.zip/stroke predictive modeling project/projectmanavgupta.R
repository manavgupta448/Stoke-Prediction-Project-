library(dplyr)
library(ggplot2)

data<- read.csv("C:/Users/manav/OneDrive/GT MABS/stroke predictive modeling project/Stroke_Prediction_Indians.csv",header=TRUE)

str(data)

dim(data)  # no of rows and columns

head(data)
colSums(is.na(data))
x<-sum(duplicated(data))

print(x)

#visualisations and statistical summaries
summary(data)

#bar plot for categorical variables 

#how many males and females are there in the dataset?
ggplot(data, aes(x=data$Gender)) + geom_bar(fill="lightblue") +
         labs(title = "gender distribution",x="Gender",y="Count")


#checking for outliers 
#median age is coming out to be 54 and the distribution is amongst the ages 37(estimate) and 72(estimate)
ggplot(data ,aes(x="",y= data$Age)) +geom_boxplot(fill="pink") + labs(title = "boxplot of the age",y="age")

# not working 
# bar plot for target variable- to understand the balance 
ggplot(data,aes(x=as.factor(data$Stroke.Occurrence)) + 
         geom_bar(fill="lightgreen") +
         labs(title = "stroke occurrence distribution",x="stroke occurrence",y="count")

       
# correlation between age and stroke occurence 
ggplot(data, aes(x= Age , fill= as.factor(data$Stroke.Occurrence) )) +
  geom_histogram(binwidth = 5 ,fill= "blue",color="black" ) +
  labs(title = "age distribution by stroke occurence" , x ="age" ,fill = "stroke occurence (0= no,1 = yes)")
       
       
       
# stoke risk in comparison to income levels 
ggplot(data, aes(x=data$Income.Level, fill=as.factor(data$Stroke.Occurrence)))+
  geom_bar(position = "fill", fill ="coral") +
  labs(title = "stroke risk across income levels",x="income level",y=" proportion ", fill="Stroke Occurrence")




#not sure
# box plot of bmi across stroke occurences 
ggplot(data, aes(x= as.factor(data$Stroke.Occurrence),y= 'BMI',fill= as.factor(data$Stroke.Occurrence))) +
  geom_boxplot() + labs(title = "bmi across stroke occurence ",x="stroke occurence",y="bmi")

#check for outliers in age 
boxplot(data$Age , main = "age outliers",horizontal=TRUE)
#shows no outliers 

#since missing values and duplicate data is not there hence
#we dont have to impute the missing values with the median value

#otherwise we would have used the following
#example - to treat missing values in bmi column 
data$BMI[is.na(data$BMI)]<- median(data$BMI,na.rm = TRUE)


#feature engineering to convert a few categorical variables to factors

data$Income.Level<- as.factor(data$Income.Level)

data$Stroke.Occurrence<- as.factor(data$Stroke.Occurrence)

# target variable and key features influencing it 
# our target variable is clearly the stroke occurrence column , it is binary i.e 0 or 1
#hence it is a binary classification problem 
#numerical variables such as age ,bmi,average glucose level,they provide features to model and 
#predict the target variable 



## MODEL DEVELOPMENT 

install.packages("caret")
library(caret)

#splitting the data(70-30)

set.seed(123)
sum(is.na(data$Stroke.Occurrence))  # Check for missing values
length(data$Stroke.Occurrence)      # Check the number of observations


trainindex <- createDataPartition(data$Stroke.Occurrence,p=0.7,list = FALSE)
traindata <- data[trainindex, ]
testdata<- data[-trainindex, ]


# checking  for missing values in columns 
colSums(is.na(traindata))
# although we dont have any missing value , if we still had it , we could use this 

sapply(traindata,length)
#all columns have 120401 rows





head(testdata)

## building a predictive model
#remove id column as it does not contain any relevant information for model training
logreg_model <- glm(Stroke.Occurrence ~ . - ID, data = traindata, family = "binomial")



summary(logreg_model)




#model prediction

prediction_testdata<- predict(logreg_model,testdata,type ="response")
print(prediction_testdata)




# Convert probabilities to class labels
testdata$predicted <- ifelse(prediction_testdata > 0.4, 1, 0)
#considered threshold to be 0.4


head(testdata)






install.packages("pROC")
library(pROC)














## model performance 
#interpreting the model



#confusion matrix

#converting the predicted and stroke occurrence column to factors with 0 and 1 for confusion matrix
testdata$predicted <- as.factor(testdata$predicted)
testdata$Stroke.Occurrence <- as.factor(testdata$Stroke.Occurrence)

#making sure that both factors predicted and stroke occurrence have the same levels i.e 0 and 1 
levels(testdata$predicted) <- levels(testdata$Stroke.Occurrence) <- c("0", "1")

#applying confusion matrix
confusionMatrix(as.factor(testdata$predicted),testdata$Stroke.Occurrence)



#AUC-ROC
roc_curve <- roc(testdata$Stroke.Occurrence, prediction_testdata)
auc(roc_curve)
plot(roc_curve, col = "coral")







library(ggplot2)




##visualisation for age vs stroke prediction(predicted probability)

# Assuming 'Age' is a key predictor for Stroke.Occurrence
# Store predicted probabilities
testdata$predicted_prob <- prediction_testdata  

# Scatter plot of Age vs predicted probability
ggplot(testdata, aes(x = Age, y = predicted_prob)) +
  geom_point(aes(color = as.factor(Stroke.Occurrence)), size = 1) +  # Color by true class (0 or 1)
  geom_smooth(method = "glm", method.args = list(family = "binomial"), se = FALSE, color = "blue") +  
  labs(title = "Predicted Stroke Probability vs Age",
       x = "Age",
       y = "Predicted Probability",
       color = "True Class") +  
  theme_minimal()









##results and analysis 



#Accuracy Analysis
#The model's reported accuracy is 90.13%, 
#but this high value is misleading because it primarily results from the class 
#imbalance in the dataset. Specifically, the majority class (no stroke occurrence) accounts
# for 90.13% of the data, meaning that a model predicting only this class will appear highly accurate.

#Since the model always predicts class 0 (no stroke occurrence),
#it achieves 100% accuracy for the majority class but completely fails to 
#predict any minority class cases (stroke occurrence)

# AUC of 0.4995:
#  The Area Under the ROC Curve (AUC) is 0.4995, which is almost equivalent to random guessing. 
# A reliable model should have an AUC significantly greater than 0.5



#Poor Generalization:
#Despite having a high accuracy, 
#the model’s inability to predict the minority class (strokes) shows that it generalizes poorly
#to real-world scenarios
#where correctly identifying stroke cases is crucial.





#Predictions: The model predicts no stroke occurrence (0)
#most of the time, likely due to the class imbalance in the dataset.
#Accuracy: The model achieves a seemingly high accuracy of 90.13% but fails
#to predict the minority class (stroke occurrence).
#Confusion Matrix: The confusion matrix confirms that the model has zero specificity, 
#meaning it does not predict any stroke occurrences (1).
#ROC and AUC: The AUC is close to 0.5, indicating the model performs almost 
#as well as random guessing.




#The AUC of 0.4995 supports the conclusion that the model has limited predictive power